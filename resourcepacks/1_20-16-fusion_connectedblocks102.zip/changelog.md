### Fusion Block Transitions 1.0.2
- Account for 1.21.9 pack.mcmeta format changes

### Fusion Block Transitions 1.0.1
- Fixed log spam on Minecraft versions with polished tuff

### Fusion Block Transitions 1.0.0
- Initial release of Fusion Connected Blocks
