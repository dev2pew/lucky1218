### Fusion Stacking Items 1.0.1
- Account for 1.21.9 pack.mcmeta format changes
- Update `chain` references to `iron_chain` for 1.21.9

### Fusion Stacking Items 1.0.0
- Initial release of Fusion Stacking Items
